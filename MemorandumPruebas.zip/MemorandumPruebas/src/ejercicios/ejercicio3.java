package ejercicios;

public class ejercicio3 {
    public static void main(String[] args) {
        Object[] arrayprincipal = {false, 1, 0, 1, 2, 0, 1, 3, "a"};
        Object[] arrayfin = moverCeros(arrayprincipal);

        // Imprimir el resultado
        System.out.println("Resultado: ");
        for (int i = 0; i < arrayfin.length; i++) {
            System.out.print(arrayfin[i] + " ");
        }
    }

    public static Object[] moverCeros(Object[] array) {
        // Crear un array del mismo tama�o que el original
        Object[] resultado = new Object[array.length];
        int indice = 0;

        // A�adir todos los elementos que no son ceros al nuevo array
        for (int i = 0; i < array.length; i++) {
            if (!(array[i] instanceof Integer && (Integer) array[i] == 0)) {
                resultado[indice] = array[i];
                indice++;
            }
        }

        // Rellenar el resto del array con ceros
        for (int i = indice; i < array.length; i++) {
            resultado[i] = 0;
        }

        return resultado;
    }
}
