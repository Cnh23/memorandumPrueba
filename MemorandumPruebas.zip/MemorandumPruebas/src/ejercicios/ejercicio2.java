package ejercicios;

import java.util.Scanner;

public class ejercicio2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Solicitar n�mero N (entero)
        System.out.println("Introduce un n�mero (N): ");
        int n = sc.nextInt();
        
        if (n <= 0) {
            System.out.println("El n�mero debe ser mayor que 0");
        } else {
            int sumaTotal = 0;
            for (int i = 1; i <= n; i++) {
                sumaTotal += sumaDeDigitos(i);
            }
            System.out.println("La suma de los d�gitos de todos los n�meros de 1 a " + n + " es: " + sumaTotal);
        }
        
    }
    
    // Funci�n para calcular la suma de los d�gitos de un n�mero
    public static int sumaDeDigitos(int numero) {
        int suma = 0;
        while (numero != 0) {
            suma += numero % 10;
            numero /= 10;
        }
        return suma;
    }
}
