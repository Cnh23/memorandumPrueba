package ejercicios;

import java.util.Scanner;

public class ejercicio1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Leer peso y altura
        System.out.println("Introduce tu peso en kilos: ");
        double peso = sc.nextDouble();
        
        System.out.println("Introduce tu altura en metros: ");
        double altura = sc.nextDouble();
        
        // Calcular IMC
        double imc = calcularIMC(peso, altura);
        
        // Determinar categor�a
        String categoria = determinarIMC(imc);
        
        // Imprimir resultado
        System.out.println("Tu IMC es " + imc + " y est�s en la categor�a: " + categoria);

    }
    
    public static double calcularIMC(double peso, double altura) {
        return peso / (altura * altura);
    }
    
    public static String determinarIMC(double imc) {
        if (imc <= 18.5) {
            return "Infrapeso";
        } else if (imc <= 25.0) {
            return "Normal";
        } else if (imc <= 30.0) {
            return "Sobrepeso";
        } else {
            return "Obeso";
        }
    }
}

